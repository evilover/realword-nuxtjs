import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _3c18be36 = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _0647ea2a = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _c244ca46 = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _3709281d = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _804ca678 = () => interopDefault(import('..\\pages\\setting' /* webpackChunkName: "" */))
const _3049e479 = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))
const _1dd36b6a = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _3c18be36,
    children: [{
      path: "",
      component: _0647ea2a,
      name: "home"
    }, {
      path: "/login",
      component: _c244ca46,
      name: "login"
    }, {
      path: "/register",
      component: _c244ca46,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _3709281d,
      name: "profile"
    }, {
      path: "/setting",
      component: _804ca678,
      name: "setting"
    }, {
      path: "/editor",
      component: _3049e479,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _1dd36b6a,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
